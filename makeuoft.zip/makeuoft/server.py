import serial.tools.list_ports
import winsound
import random

print(random.randint(3, 9))

ports = serial.tools.list_ports.comports()
serialInst = serial.Serial()

portsList = []
THRESHOLD = 0
# THRESHOLD is the constant that the frequency must be over to open a webpage

for onePort in ports:
    portsList.append(str(onePort))
#    print(str(onePort))

#val = input("Select Port: COM")

for x in range(0, len(portsList)):
    if portsList[x].startswith("COM3"):
#    if portsList[x].startswith("COM" + str(val)):
        portVar = "COM3"
#        portVar = "COM" + str(val)
        print(portVar)

serialInst.baudrate = 9600
serialInst.port = portVar
serialInst.open()

past = 0
print("COM initialized")
while True:
    packet = serialInst.readline()
    print(packet)
    if float(packet.decode('utf').rstrip('\n')) - past > 45:
#        video = 'https://youtu.be/EqOXTeBZ-ew'
#        webbrowser.open(video)
#        rand = random.randint(0, 9)
        winsound.PlaySound('explosion.wav', winsound.SND_FILENAME)
    elif float(packet.decode('utf').rstrip('\n')) - past > 25:
        winsound.PlaySound('voom.wav', winsound.SND_FILENAME)
